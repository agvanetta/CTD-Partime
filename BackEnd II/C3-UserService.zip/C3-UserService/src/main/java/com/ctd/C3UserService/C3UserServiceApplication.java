package com.ctd.C3UserService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C3UserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(C3UserServiceApplication.class, args);
	}

}
