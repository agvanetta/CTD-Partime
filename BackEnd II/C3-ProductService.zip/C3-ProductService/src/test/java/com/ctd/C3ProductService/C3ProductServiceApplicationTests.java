package com.ctd.C3ProductService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C3ProductServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
