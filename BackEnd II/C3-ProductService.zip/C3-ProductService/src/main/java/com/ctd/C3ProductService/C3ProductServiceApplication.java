package com.ctd.C3ProductService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C3ProductServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(C3ProductServiceApplication.class, args);
	}

}
