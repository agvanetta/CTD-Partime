# spring-cloud-config-class-6
Spring Cloud Config on Class 6
